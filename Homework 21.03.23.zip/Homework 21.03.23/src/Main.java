public class Main {
    public static void main(String[] args) {
        String st = concat(" Первая строка ", " Вторая строка ", " Третья строка ", "|");
        System.out.println(st);
        String str = "Я учу Java";
        char c = str.charAt(0);
        System.out.println(c);
    }

    private static String concat(String st1, String st2, String st3, String delimiter) {
        return st1 + delimiter + st2 + delimiter + st3;
    }

}
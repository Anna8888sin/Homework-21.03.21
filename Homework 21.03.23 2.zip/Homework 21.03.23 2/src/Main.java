public class Main {
    // Напишите метод, который выводит в консоль
    //первый символ переданной в него строки.
    public static void main(String[] args) {
        String str = "I study English!";
        text(str);
    }

    private static void text(String str) {
        System.out.println(str.charAt(0));

    }

}